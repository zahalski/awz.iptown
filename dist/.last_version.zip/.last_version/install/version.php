<?
$arModuleVersion = array(
	"VERSION" => "1.0.1",
	"VERSION_DATE" => "2023-06-25 10:57:00"
);
?>